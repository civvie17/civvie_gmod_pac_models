list.Set( "PlayerOptionsModel", "Natilime", "models/radilime/rad/rad_human.mdl")
player_manager.AddValidModel( "Natilime", "models/radilime/rad/rad_human.mdl")
player_manager.AddValidHands( "Natilime", "models/radilime/rad/rad_hcarms.mdl", 0, "00000000" )

if CLIENT then

    local function Viewmodel( vm, ply, weapon )
        if CLIENT then
            if ply:GetModel() == "models/radilime/rad/rad_human.mdl" then
                local skin = ply:GetSkin()
                local hands = ply:GetHands()
                if ( weapon.UseHands or !weapon:IsScripted() ) then
                    if ( IsValid( hands ) ) then
                        hands:DrawModel()
                        hands:SetSkin( skin )
                    end
                end
            end
        end
    end
    hook.Add( "PostDrawViewModel", "rad_human", Viewmodel )
end