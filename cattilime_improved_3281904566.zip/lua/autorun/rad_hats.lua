	hook.Add( "PopulatePropMenu", "Cattilime", function() 

	local contents = {}

	table.insert( contents, {
		type = "header",
		text = "Cattilime"
	} )
	
	table.insert( contents, {
		type = "model",
		model = "models/radilime/rad/rad.mdl",
		wide = 128,
		tall = 256
	} )		
	
	table.insert( contents, {
		type = "model",
		model = "models/radilime/rad/rad_human.mdl",
		wide = 128,
		tall = 256
	} )

	table.insert( contents, {
		type = "header",
		text = "Hats"
	} )
	
	table.insert( contents, {
		type = "model",
		model = "models/radilime/props/hat_western.mdl",
		wide = 128,
		tall = 128
	} )		
	
	table.insert( contents, {
		type = "model",
		model = "models/radilime/props/hat_wizard.mdl",
		wide = 128,
		tall = 128

	} )
	table.insert( contents, {
		type = "model",
		model = "models/radilime/props/helmet_ww1uk.mdl",
		wide = 128,
		tall = 128
	} )		
	
	table.insert( contents, {
		type = "model",
		model = "models/radilime/props/rad_cap.mdl",
		wide = 128,
		tall = 128
	} )

		spawnmenu.AddPropCategory( "Cattilime", "Cattilime", contents, "vgui/catty.png" )
end )		