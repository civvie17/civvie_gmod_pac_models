list.Set( "PlayerOptionsModel", "Cattilime", "models/radilime/rad/rad.mdl")
player_manager.AddValidModel( "Cattilime", "models/radilime/rad/rad.mdl")
player_manager.AddValidHands( "Cattilime", "models/radilime/rad/rad_carms.mdl", 0, "00000000" )

if CLIENT then

    local function Viewmodel( vm, ply, weapon )
        if CLIENT then
            if ply:GetModel() == "models/radilime/rad/rad.mdl" then
                local skin = ply:GetSkin()
                local hands = ply:GetHands()
                if ( weapon.UseHands or !weapon:IsScripted() ) then
                    if ( IsValid( hands ) ) then
                        hands:DrawModel()
                        hands:SetSkin( skin )
                    end
                end
            end
        end
    end
    hook.Add( "PostDrawViewModel", "rad", Viewmodel )
end